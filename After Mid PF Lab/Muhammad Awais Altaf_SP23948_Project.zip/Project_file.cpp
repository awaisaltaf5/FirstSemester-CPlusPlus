//Project on Bank Management System
#include <iostream>
#include <string>
using namespace std;

const int max_accounts = 100; // Maximum number of accounts

struct bankAccount {
    string accountHolderName;
    int accountNumber;
    float balance;
    string accountType;
    float interestrate;
};

bankAccount accounts[max_accounts];
int numAccounts = 0;

void createAccount() {
    if (numAccounts >= max_accounts) {
        cout << "Maximum number of accounts reached!" << endl;
        return;
    }
    bankAccount newAccount;
    cout << "Enter Account Holder Name: ";
    cin.ignore();
    getline(cin, newAccount.accountHolderName);
    cout << "Enter Account Number: ";
    cin >> newAccount.accountNumber;
    cout << "Enter Initial Balance: ";
    cin >> newAccount.balance;
    cin.ignore(); // Clear the newline character left in the buffer & buffer is a temporary storage 
    
    cout << "Enter the Account Type (Savings/Checking): ";
    getline(cin, newAccount.accountType);
    if (newAccount.accountType == "Savings") {
        cout << "Enter Interest Rate: ";
        cin >> newAccount.interestrate;
    } else {
        newAccount.interestrate = 0.0f;
    }
    accounts[numAccounts++] = newAccount;
    cout << "Account created successfully!" << endl;
}

void viewAccountDetails() {
    int accountNumber;
    cout << "Enter Account Number: ";
    cin >> accountNumber;
    for (int i = 0; i < numAccounts; ++i) {
        if (accounts[i].accountNumber == accountNumber) {
            cout << "Account Holder Name: " << accounts[i].accountHolderName << endl;
            cout << "Account Number: " << accounts[i].accountNumber << endl;
            cout << "Balance: " << accounts[i].balance << endl;
            cout << "Account Type: " << accounts[i].accountType << endl;
            cout << "Interest Rate: " << accounts[i].interestrate << "%" << endl;
            return;
        }
    }
    cout << "Account not found!" << endl;
}

void deposit() {
    int accountNumber;
    float amount;
    cout << "Enter Account Number: ";
    cin >> accountNumber;
    cout << "Enter Amount to Deposit: ";
    cin >> amount;
    for (int i = 0; i < numAccounts; ++i) {
        if (accounts[i].accountNumber == accountNumber) {
            accounts[i].balance += amount;
            cout << "Deposit successful!" << endl;
            return;
        }
    }
    cout << "Account not found!" << endl;
}

void withdraw() {
    int accountNumber;
    float amount;
    cout << "Enter Account Number: ";
    cin >> accountNumber;
    cout << "Enter Amount to Withdraw: ";
    cin >> amount;
    for (int i = 0; i < numAccounts; ++i) {
        if (accounts[i].accountNumber == accountNumber) {
            if (accounts[i].balance >= amount) {
                accounts[i].balance -= amount;
                cout << "Withdrawal successful!" << endl;
            } else {
                cout << "Insufficient balance!" << endl;
            }
            return;
        }
    }
    cout << "Account not found!" << endl;
}

void transfer() {
    int fromAccount, toAccount;
    float amount;
    cout << "Enter From Account Number: ";
    cin >> fromAccount;
    cout << "Enter To Account Number: ";
    cin >> toAccount;
    cout << "Enter Amount to Transfer: ";
    cin >> amount;

    int fromIndex = -1, toIndex = -1;
    for (int i = 0; i < numAccounts; ++i) {
        if (accounts[i].accountNumber == fromAccount) {
            fromIndex = i;
        }
        if (accounts[i].accountNumber == toAccount) {
            toIndex = i;
        }
    }

    if (fromIndex == -1 || toIndex == -1) {
        cout << "Account not found!" << endl;
        return;
    }

    if (accounts[fromIndex].balance >= amount) {
        accounts[fromIndex].balance -= amount;
        accounts[toIndex].balance += amount;
        cout << "Transfer successful!" << endl;
    } else {
        cout << "Insufficient balance!" << endl;
    }
}

void viewAllAccounts() {
    for (int i = 0; i < numAccounts; ++i) {
        cout << "Account Holder Name: " << accounts[i].accountHolderName << endl;
        cout << "Account Number: " << accounts[i].accountNumber << endl;
        cout << "Balance: " << accounts[i].balance << endl;
        cout << "Account Type: " << accounts[i].accountType << endl;
        cout << "Interest Rate: " << accounts[i].interestrate << "%" << endl;
        cout << "---------------------------------" << endl;
    }
}

void calculateInterest() {
    for (int i = 0; i < numAccounts; ++i) {
        if (accounts[i].accountType == "Savings") {
            accounts[i].balance += (accounts[i].balance * accounts[i].interestrate / 100);
        }
    }
    cout << "Interest calculated for all Savings accounts." << endl;
}

void closeAccount() {
    int accountNumber;
    cout << "Enter Account Number: ";
    cin >> accountNumber;
    for (int i = 0; i < numAccounts; ++i) {
        if (accounts[i].accountNumber == accountNumber) {
            for (int j = i; j < numAccounts - 1; ++j) {
                accounts[j] = accounts[j + 1];
            }
            numAccounts--;
            cout << "Account closed successfully!" << endl;
            return;
        }
    }
    cout << "Account not found!" << endl;
}

int main() {
    int choice;
    do {
        cout << "\n--- Banking Management System ---\n";
        cout<<"\n\"Instructions:Don't double tap the button at a single time!\"";
        cout << "\n1. Create a new account\n";
        cout << "2. View account details\n";
        cout << "3. Deposit money\n";
        cout << "4. Withdraw money\n";
        cout << "5. Transfer money between accounts\n";
        cout << "6. View all accounts\n";
        cout << "7. Calculate interest for Savings accounts\n";
        cout << "8. Close an account\n";
        cout << "9. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        switch (choice) {
            case 1: createAccount(); break;
            case 2: viewAccountDetails(); break;
            case 3: deposit(); break;
            case 4: withdraw(); break;
            case 5: transfer(); break;
            case 6: viewAllAccounts(); break;
            case 7: calculateInterest(); break;
            case 8: closeAccount(); break;
            case 9: cout << "Exiting program." << endl; break;
            default: cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != 9);
    return 0;
}
